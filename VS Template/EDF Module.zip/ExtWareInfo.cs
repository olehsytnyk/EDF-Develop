﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WheelsScraper;

namespace $safeprojectname$
{
	public class ExtWareInfo : WareInfo
	{
	}
}
